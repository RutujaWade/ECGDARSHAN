
import io
import re
import zipfile
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import streamlit as st
from pypdf import PdfReader


st.set_page_config(
    page_title="ECG PDF Risk Assessment",
    page_icon="🫀",
    layout="wide",
)

RISK_COLORS = {
    1: "#2E7D32",
    2: "#66BB6A",
    3: "#F9A825",
    4: "#EF6C00",
    5: "#C62828",
}


def extract_pdf_text(pdf_file) -> str:
    reader = PdfReader(pdf_file)
    pages = []
    for page in reader.pages:
        pages.append(page.extract_text() or "")
    return "\n".join(pages)


def find_number(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1))
            except (ValueError, IndexError):
                continue
    return np.nan


def find_number_pair(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1)), float(match.group(2))
            except (ValueError, IndexError):
                continue
    return np.nan, np.nan


def find_number_triple(text, patterns):
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                return (
                    float(match.group(1)),
                    float(match.group(2)),
                    float(match.group(3)),
                )
            except (ValueError, IndexError):
                continue
    return np.nan, np.nan, np.nan


def parse_ecg_pdf_text(text: str) -> dict:
    clean_text = re.sub(r"[ \t]+", " ", text)

    qt_value, qtc_value = find_number_pair(
        clean_text,
        [
            r"QT\s*/\s*QTc(?:Bz)?\s*:\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)",
            r"QT\s*/\s*QTcB\s*:\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)",
        ],
    )

    p_axis, qrs_axis, t_axis = find_number_triple(
        clean_text,
        [
            r"P\s*/\s*QRS\s*/\s*T\s*:\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)"
        ],
    )

    rv5_value, sv1_value = find_number_pair(
        clean_text,
        [
            r"RV5\s*/\s*SV1\s*:\s*(-?\d+(?:\.\d+)?)\s*/\s*(-?\d+(?:\.\d+)?)"
        ],
    )

    record = {
        "heart_rate_bpm": find_number(
            clean_text,
            [
                r"\bHR\s*:\s*(\d+(?:\.\d+)?)",
                r"Heart Rate\s*:\s*(\d+(?:\.\d+)?)",
                r"Vent\.?\s*Rate\s*:\s*(\d+(?:\.\d+)?)",
            ],
        ),
        "p_duration_ms": find_number(
            clean_text, [r"\bP\s*:\s*(\d+(?:\.\d+)?)\s*ms"]
        ),
        "pr_interval_ms": find_number(
            clean_text, [r"\bPR\s*:\s*(\d+(?:\.\d+)?)\s*ms"]
        ),
        "qrs_duration_ms": find_number(
            clean_text, [r"\bQRS\s*:\s*(\d+(?:\.\d+)?)\s*ms"]
        ),
        "qt_interval_ms": qt_value,
        "qtc_bazett_ms": qtc_value,
        "p_axis_deg": p_axis,
        "qrs_axis_deg": qrs_axis,
        "t_axis_deg": t_axis,
        "rv5_mv": rv5_value,
        "sv1_mv": sv1_value,
        "rhythm": "Unknown",
        "primary_label": "Unknown",
        "machine_findings_text": "",
    }

    known_findings = [
        "Sinus Tachycardia",
        "Sinus Bradycardia",
        "Sinus Arrhythmia",
        "Sinus Rhythm",
        "Larged PtfV1",
        "Large PtfV1",
        "T Wave Abnormality",
        "ST-T Abnormality",
        "Left Ventricular Hypertrophy",
        "High Voltage",
        "Poor R Wave Progression",
        "Premature Ventricular Contraction",
        "Premature Atrial Contraction",
        "Atrial Fibrillation",
        "Atrial Flutter",
        "First Degree AV Block",
        "Right Bundle Branch Block",
        "Left Bundle Branch Block",
        "Bundle Branch Block",
        "Prolonged QT",
        "Acute Myocardial Infarction",
        "Myocardial Infarction",
        "STEMI",
        "Ventricular Tachycardia",
        "Ventricular Fibrillation",
        "Complete Heart Block",
        "Third Degree AV Block",
        "Torsades",
        "Asystole",
        "AV Sequential-paced Complexes",
        "Atrial Paced Rhythm",
        "Ventricular Paced Rhythm",
        "Dual Chamber Paced Rhythm",
        "Paced Rhythm",
        "Pacemaker Rhythm",
        "Lead Off",
        "Electrode Reversal",
        "Normal ECG",
    ]

    detected = []
    for finding in known_findings:
        if re.search(re.escape(finding), clean_text, re.IGNORECASE):
            detected.append(finding)

    detected = list(dict.fromkeys(detected))
    record["machine_findings_text"] = " | ".join(detected)

    if detected:
        record["primary_label"] = detected[0]

    rhythm_priority = [
        "Ventricular Tachycardia",
        "Ventricular Fibrillation",
        "Atrial Fibrillation",
        "Atrial Flutter",
        "Sinus Tachycardia",
        "Sinus Bradycardia",
        "Sinus Arrhythmia",
        "Sinus Rhythm",
        "AV Sequential-paced Complexes",
        "Atrial Paced Rhythm",
        "Ventricular Paced Rhythm",
        "Dual Chamber Paced Rhythm",
        "Paced Rhythm",
        "Pacemaker Rhythm",
    ]

    for rhythm_name in rhythm_priority:
        if rhythm_name in detected:
            record["rhythm"] = rhythm_name
            break

    return record


def detect_quality_problem(record: dict, numeric_features: list[str]):
    text = " | ".join(
        [
            str(record.get("primary_label", "")),
            str(record.get("machine_findings_text", "")),
            str(record.get("rhythm", "")),
        ]
    ).lower()

    if "lead off" in text:
        return "One or more ECG leads were disconnected. Repeat the ECG before risk assessment."

    if "electrode reversal" in text:
        return "Possible electrode reversal. Verify electrode placement and repeat the ECG."

    values = [record.get(feature, np.nan) for feature in numeric_features]
    missing_count = sum(pd.isna(value) for value in values)

    if missing_count >= max(6, int(len(values) * 0.7)):
        return "Too many ECG measurements could not be extracted from this PDF."

    return None


def detect_level5_critical_rule(record: dict, critical_patterns: dict):
    combined = " | ".join(
        [
            str(record.get("machine_findings_text", "")),
            str(record.get("primary_label", "")),
            str(record.get("rhythm", "")),
        ]
    )

    reasons = []
    for reason, patterns in critical_patterns.items():
        for pattern in patterns:
            if re.search(pattern, combined, re.IGNORECASE):
                reasons.append(reason)
                break
    return list(dict.fromkeys(reasons))


def normalize_to_five(probabilities, residual=0.01):
    probabilities = np.asarray(probabilities, dtype=float)
    probabilities = probabilities / probabilities.sum()
    return np.concatenate([probabilities * (1 - residual), [residual]])


def critical_distribution(probabilities, level5_score=0.90):
    probabilities = np.asarray(probabilities, dtype=float)
    probabilities = probabilities / probabilities.sum()
    return np.concatenate([probabilities * (1 - level5_score), [level5_score]])


@st.cache_resource
def load_model_bundle(model_zip_path: str):
    extract_dir = Path(".ecg_model")
    extract_dir.mkdir(exist_ok=True)

    with zipfile.ZipFile(model_zip_path, "r") as archive:
        archive.extractall(extract_dir)

    model_candidates = list(extract_dir.rglob("ecg_risk_model_levels_1_to_4.pkl"))
    config_candidates = list(extract_dir.rglob("ecg_hybrid_model_config.pkl"))

    if not model_candidates or not config_candidates:
        raise FileNotFoundError(
            "Model ZIP must contain ecg_risk_model_levels_1_to_4.pkl "
            "and ecg_hybrid_model_config.pkl"
        )

    model = joblib.load(model_candidates[0])
    config = joblib.load(config_candidates[0])
    return model, config


def predict_record(record: dict, model, config):
    numeric_features = config["numeric_features"]
    categorical_features = config["categorical_features"]
    all_features = config["all_features"]
    critical_patterns = config["critical_level5_patterns"]

    quality_problem = detect_quality_problem(record, numeric_features)
    if quality_problem:
        return {"status": "manual_review", "quality_problem": quality_problem}

    row = {feature: record.get(feature, np.nan) for feature in all_features}
    input_df = pd.DataFrame([row])

    for feature in categorical_features:
        input_df[feature] = input_df[feature].fillna("Unknown").astype(str)

    model_probs = model.predict_proba(input_df)[0]
    critical_reasons = detect_level5_critical_rule(record, critical_patterns)

    if critical_reasons:
        probs = critical_distribution(model_probs)
        predicted_level = 5
        source = "Critical rule layer"
    else:
        probs = normalize_to_five(model_probs)
        predicted_level = int(np.argmax(probs) + 1)
        source = "Calibrated machine-learning model"

    expected_score = sum(level * probs[level - 1] for level in range(1, 6))

    return {
        "status": "predicted",
        "predicted_level": predicted_level,
        "predicted_name": config["risk_level_names"][predicted_level],
        "confidence": float(probs[predicted_level - 1]),
        "expected_score": float(expected_score),
        "probabilities": probs,
        "critical_reasons": critical_reasons,
        "prediction_source": source,
    }


def confidence_note(result: dict) -> str:
    if result["status"] != "predicted":
        return ""

    probs = np.asarray(result["probabilities"])
    top_two = np.sort(probs)[-2:]
    margin = float(top_two[-1] - top_two[-2])

    if result["confidence"] < 0.50:
        return "Low-confidence prediction. Expert review is strongly recommended."
    if result["confidence"] < 0.65:
        return "Moderate confidence. Clinical review is recommended."
    if margin < 0.15:
        return "The two highest risk levels are close. Interpret with caution."
    return "Prediction confidence is acceptable for screening support."


st.title("🫀 ECG PDF Risk Assessment")
st.caption("Upload a text-based ECG PDF and receive a five-level screening result.")

with st.sidebar:
    st.header("Model setup")
    model_zip_path = st.text_input(
        "Model ZIP path",
        value="ecg_hybrid_model_outputs.zip",
        help="Place the Notebook 5 output ZIP in the same folder as app.py.",
    )
    st.info(
        "Required files inside ZIP:\n"
        "- ecg_risk_model_levels_1_to_4.pkl\n"
        "- ecg_hybrid_model_config.pkl"
    )

try:
    model, config = load_model_bundle(model_zip_path)
    st.sidebar.success("Model loaded")
except Exception as exc:
    st.sidebar.error(f"Model loading failed: {exc}")
    st.stop()

uploaded_pdf = st.file_uploader("Upload ECG PDF", type=["pdf"])

if uploaded_pdf is not None:
    try:
        pdf_text = extract_pdf_text(uploaded_pdf)
    except Exception as exc:
        st.error(f"Could not read PDF: {exc}")
        st.stop()

    if not pdf_text.strip():
        st.error(
            "No embedded text was found. This may be a scanned/image-only PDF. "
            "OCR processing is required first."
        )
        st.stop()

    record = parse_ecg_pdf_text(pdf_text)
    result = predict_record(record, model, config)

    if result["status"] == "manual_review":
        st.warning("Manual review or repeat ECG required")
        st.write(result["quality_problem"])
    else:
        level = result["predicted_level"]
        color = RISK_COLORS[level]

        st.markdown(
            f"""
            <div style="
                padding: 20px;
                border-radius: 14px;
                background: {color};
                color: white;
                text-align: center;
                margin-bottom: 18px;">
                <div style="font-size: 18px;">Predicted Screening Risk</div>
                <div style="font-size: 34px; font-weight: 700;">
                    Level {level} — {result["predicted_name"]}
                </div>
                <div style="font-size: 17px;">
                    Confidence: {result["confidence"] * 100:.2f}%
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        col1, col2, col3 = st.columns(3)
        col1.metric("Risk level", f"{level}/5")
        col2.metric("Confidence", f'{result["confidence"] * 100:.2f}%')
        col3.metric("Expected score", f'{result["expected_score"]:.2f}/5')

        st.subheader("Five-level probabilities")
        probability_df = pd.DataFrame(
            {
                "Risk level": [
                    f"Level {i} — {config['risk_level_names'][i]}"
                    for i in range(1, 6)
                ],
                "Probability (%)": [
                    round(float(p) * 100, 2) for p in result["probabilities"]
                ],
            }
        )
        st.bar_chart(probability_df.set_index("Risk level"))
        st.dataframe(probability_df, use_container_width=True, hide_index=True)

        st.subheader("Possible ECG findings")
        findings = [
            item.strip()
            for item in record["machine_findings_text"].split("|")
            if item.strip()
        ]
        if findings:
            for finding in findings:
                st.write(f"• {finding}")
        else:
            st.write("No machine-reported finding was detected.")

        st.subheader("Extracted ECG parameters")
        display_record = {
            "Heart rate (bpm)": record["heart_rate_bpm"],
            "P duration (ms)": record["p_duration_ms"],
            "PR interval (ms)": record["pr_interval_ms"],
            "QRS duration (ms)": record["qrs_duration_ms"],
            "QT interval (ms)": record["qt_interval_ms"],
            "QTc Bazett (ms)": record["qtc_bazett_ms"],
            "P axis (°)": record["p_axis_deg"],
            "QRS axis (°)": record["qrs_axis_deg"],
            "T axis (°)": record["t_axis_deg"],
            "RV5 (mV)": record["rv5_mv"],
            "SV1 (mV)": record["sv1_mv"],
            "Rhythm": record["rhythm"],
            "Primary label": record["primary_label"],
        }
        st.dataframe(
            pd.DataFrame(
                [{"Parameter": key, "Value": value} for key, value in display_record.items()]
            ),
            use_container_width=True,
            hide_index=True,
        )

        st.subheader("Assessment note")
        st.info(confidence_note(result))

        if result["critical_reasons"]:
            st.error("Critical rule triggers: " + ", ".join(result["critical_reasons"]))

        st.caption(f'Prediction source: {result["prediction_source"]}')

        result_row = {
            "pdf_name": uploaded_pdf.name,
            "predicted_level": level,
            "predicted_name": result["predicted_name"],
            "confidence": result["confidence"],
            "expected_score": result["expected_score"],
            "findings": record["machine_findings_text"],
            **record,
        }
        csv_data = pd.DataFrame([result_row]).to_csv(index=False).encode("utf-8")

        st.download_button(
            "Download result CSV",
            data=csv_data,
            file_name=f"{Path(uploaded_pdf.name).stem}_prediction.csv",
            mime="text/csv",
        )

with st.expander("Important disclaimer"):
    st.write(
        "This application provides ECG-based screening support only. "
        "It does not provide a confirmed diagnosis and must not replace "
        "assessment by a qualified healthcare professional."
    )
